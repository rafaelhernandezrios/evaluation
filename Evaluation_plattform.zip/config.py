
import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "default_secret_key")
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/evaluation_system")
    OPENAI_API_KEY = "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"
